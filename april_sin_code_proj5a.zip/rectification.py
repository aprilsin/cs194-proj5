def blend(im1, im2, alpha):
    """ Blend two images together """
    pass

def rectify(im1, im2):
    pass