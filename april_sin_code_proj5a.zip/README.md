# Project 05: [Auto]Stitching Photo Mosaics - Part 1

Name: April Sin
SID: 3035168618

### Requirements:

None

### Instructions:

To run the code, run each cell in the iPython notebook of `main.ipynb`.
